node app.js
各个终端通过 hashchange 接入 web socket 同步