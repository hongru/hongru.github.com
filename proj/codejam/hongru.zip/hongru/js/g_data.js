/* g_data */
g_data = {
	'font': {
		'loading': {
			"outline_b": 0,
			"font": "Microsoft YaHei",
			"outline": 1.0,
			"base_b": 255,
			"base_g": 255,
			"outline_r": 0,
			"base_r": 255,
			"size": 80,
			"id": "loading",
			"outline_g": 0
			
		}
	},
	imageW: {
		map1: {
			data: [
				[0, 0, 1023, 767, 0, 0, 1023, 767]
			],
			filename: 'images/map.jpg'
		},
		role_wait: {
			info: {
				"nbrOfFrames": 2,
				"pivoty": 64,
				"framerate": 4,
				"pivotx": 53,
				"events": []
			},
			data: [
				[0, 0, 105, 127, 0, 0, 105, 127],
				[106, 0, 211, 127, 106, 0, 211, 127]
			],
			filename: 'images/spirit.png'
		},
		role_run: {
			info: {
				"nbrOfFrames": 3,
				"pivoty": 64,
				"framerate": 8,
				"pivotx": 53,
				"events": []
			},
			data: [
				[212, 0, 317, 127, 212, 0, 317, 127],
				[318, 0, 423, 127, 318, 0, 423, 127],
				[424, 0, 529, 127, 424, 0, 529, 127]
			],
			filename: 'images/spirit.png'
		},
		
		grid: {
			data: [
				[0, 0, 371, 61, 0, 0, 371, 61]
			],
			filename: 'images/grid_w.png'
		},
		ship: {
			data: [
				[0, 0, 23, 23, 0, 0, 23, 23],
				[24, 0, 47, 23, 24, 0, 47, 23],
				[48, 0, 71, 23, 48, 0, 71, 23],
				[72, 0, 95, 23, 72, 0, 95, 23],
				[96, 0, 119, 23, 96, 0, 119, 23],
				[120, 0, 143, 23, 120, 0, 143, 23],
				[144, 0, 167, 23, 144, 0, 167, 23]
			],
			filename: 'images/ship.png'
		},
		enemy: {
			data: [
				[8, 8, 23, 23, 8, 8, 23, 23]
			],
			filename: 'images/mine.png'
		},
		explosion: {
			data: [
				[0, 0, 31, 31, 0, 0, 31, 31],
				[32, 0, 63, 31, 32, 0, 63, 31],
				[64, 0, 95, 31, 64, 0, 95, 31]
			],
			filename: 'images/explosion.png'
		},
		plasma: {
			data: [
				[42, 42, 49, 95, 42, 42, 49, 95]
			],
			filename: 'images/plasma.png'
		}
	},
};