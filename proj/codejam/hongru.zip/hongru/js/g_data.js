/* g_data */
g_data = {
	'font': {
		'loading': {
			"outline_b": 0,
			"font": "Microsoft YaHei",
			"outline": 1.0,
			"base_b": 255,
			"base_g": 255,
			"outline_r": 0,
			"base_r": 255,
			"size": 80,
			"id": "loading",
			"outline_g": 0
			
		}
	},
	imageW: {
		map1: {
			data: [
				[0, 0, 1023, 767, 0, 0, 1023, 767]
			],
			filename: 'images/map.jpg'
		},
		circle: {
			data: [
				[0, 0, 109, 58, 0, 0, 109, 58]
			],
			filename: 'images/circle.png'
		},
		pie: {
			data: [
				[0, 0, 75, 45, 0, 0, 75, 45]
			],
			filename: 'images/pie.png'
		},
		
		// role status
		role_wait: {
			info: {
				"nbrOfFrames": 2,
				"pivoty": 150,
				"framerate": 4,
				"pivotx": 136,
				"events": []
			},
			data: [
				[1212,0,1514,181,1212,0,1514,181],
				[1515,0,1817,181,1515,0,1817,181]
			],
			filename: 'images/role/role-right.png'
		},
		role_run: {
			info: {
				"nbrOfFrames": 4,
				"pivoty": 150,
				"framerate": 8,
				"pivotx": 136,
				"events": []
			},
			data: [
				[0,0,302,181,0,0,302,181],
				[303,0,605,181,303,0,605,181],
				[606,0,908,181,606,0,908,181],
				[909,0,1211,181,909,0,1211,181]
			],
			filename: 'images/role/role-right.png'
		},
		role_attack: {
			info: {
				"nbrOfFrames": 3,
				"pivoty": 150,
				"framerate": 8,
				"pivotx": 136,
				"events": []
			},
			data: [
				[3030,0,3332,181,3030,0,3332,181],
				[3333,0,3635,181,3333,0,3635,181],
				[3636,0,3938,181,3636,0,3938,181]
			],
			filename: 'images/role/role-right.png'
		},
		role_attacked: {
			info: {
				"nbrOfFrames": 2,
				"pivoty": 150,
				"framerate": 4,
				"pivotx": 136,
				"events": []
			},
			data: [
				[3939,0,4241,181,3939,0,4241,181],
				[4242,0,4544,181,4242,0,4544,181]
			],
			filename: 'images/role/role-right.png'
		},
		
		// monster
		monster: {
			info: {
				"nbrOfFrames": 4,
				"pivoty": 100,
				"framerate": 4,
				"pivotx": 60,
				"events": []
			},
			data: [
				[0,0,97,109,0,0,97,109],
				[98,0,195,109,98,0,195,109],
				[196,0,293,109,196,0,293,109],
				[294,0,391,109,294,0,391,109]
			],
			filename: 'images/monster/left.png'
		},
		
		// skill icon
		skill1: {
			data: [
				[0, 0, 79, 79, 0, 0, 79, 79]
			],
			filename: 'images/skillicon/1.png'
		},
		skill2: {
			data: [
				[0, 0, 79, 79, 0, 0, 79, 79]
			],
			filename: 'images/skillicon/2.png'
		},
		skill3: {
			data: [
				[0, 0, 79, 79, 0, 0, 79, 79]
			],
			filename: 'images/skillicon/3.png'
		},
		skill4: {
			data: [
				[0, 0, 79, 79, 0, 0, 79, 79]
			],
			filename: 'images/skillicon/4.png'
		},
		skill5: {
			data: [
				[0, 0, 79, 79, 0, 0, 79, 79]
			],
			filename: 'images/skillicon/5.png'
		},
		skill_hl: {
			data: [
				[0, 0, 79, 79, 0, 0, 79, 79]
			],
			filename: 'images/skillicon/highlight.png'
		},
		
		// skill anim
		skillAnim1: {
			info: {
				"nbrOfFrames": 3,
				"pivoty": 150,
				"framerate": 4,
				"pivotx": 136,
				"events": []
			},
			data: [
				[0,0,302,181,0,0,302,181],
				[303,0,605,181,303,0,605,181],
				[606,0,908,181,606,0,908,181]
			],
			filename: 'images/skillanim/skill1.png'
		}
	},
};